/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author daizihan
 */
public class testSchedule {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        File f = new File("/Users/daizhenjin/Downloads/测试文件.xlsx");

        //try {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(f));
        XSSFWorkbook hssfWorkbook = new XSSFWorkbook(bis);
        XSSFSheet sheet = hssfWorkbook.getSheetAt(0);
        int lastRow = sheet.getLastRowNum();

        //第一页
        int row = 0;
        ArrayList<ArrayList<String>> course = new ArrayList<>();
        while (row <= lastRow) {
            XSSFRow rowContent = sheet.getRow(row);
            if (rowContent != null) {
                int col = 0;
                while (col <= 1708) {
                    XSSFCell cell = sheet.getRow(row).getCell(col);
                    if (cell != null) {
                        String currentData = "";
                        switch (cell.getCellType()) {
                            case STRING:
                                currentData = cell.getStringCellValue();
                                break;
                            case NUMERIC:
                                currentData = Double.toString(cell.getNumericCellValue());
                                break;
                        }
                        if (currentData.contains("Units")) {
                            ArrayList<String> currentCourse = new ArrayList<>();
                            // Course Name
                            XSSFCell courseName = sheet.getRow(row).getCell(col - 1);
                            String finalCourseName = "";
                            if (courseName != null) {
                                finalCourseName = courseName.getStringCellValue();
                            }
                            currentCourse.add(finalCourseName);

                            // Units and Grading
                            XSSFCell unitAndGrading = sheet.getRow(row).getCell(col);
                            String unit = "";
                            String grading = "";
                            if (unitAndGrading != null) {
                                unit = splitUnitsAndGrading(unitAndGrading.getStringCellValue()).get(0);
                                grading = splitUnitsAndGrading(unitAndGrading.getStringCellValue()).get(1);
                            }
                            currentCourse.add(unit);
                            currentCourse.add(grading);

                            // Day
                            XSSFCell day = sheet.getRow(row).getCell(col + 1);
                            String finalDay = "";
                            if (day != null) {
                                finalDay = day.getStringCellValue();
                            }
                            currentCourse.add(finalDay);

                            // Time
                            XSSFCell time = sheet.getRow(row).getCell(col + 2);
                            String finalTime = "";
                            if (time != null) {
                                finalTime = time.getStringCellValue();
                            }
                            currentCourse.add(finalTime);

                            // Place
                            XSSFCell place = sheet.getRow(row).getCell(col + 3);
                            String finalPlace = "";
                            if (place != null) {
                                finalPlace = place.getStringCellValue();
                            }
                            currentCourse.add(finalPlace);

                            int move = 0;
                            if (finalPlace.equals("T.B.A.")) {
                                move = -1;
                            }

                            // Instructor
                            XSSFCell instructor = sheet.getRow(row).getCell(col + 4 + move);
                            String finalInstructor = "";
                            if (instructor != null) {
                                finalInstructor = instructor.getStringCellValue();
                            }
                            currentCourse.add(finalInstructor);

                            // Space
                            XSSFCell space = sheet.getRow(row).getCell(col + 5 + move);
                            String finalSpace = "";
                            if (space != null) {
                                finalSpace = space.getStringCellValue();
                            }
                            currentCourse.add(finalSpace);

                            // MaxSpace
                            XSSFCell maxSpace = sheet.getRow(row).getCell(col + 6 + move);
                            String finalMaxSpace = "";
                            System.out.println(courseName);
                            System.out.println(maxSpace.getCellType());
                            if (maxSpace != null) {
                                finalMaxSpace = maxSpace.getStringCellValue();
                            }
                            currentCourse.add(finalMaxSpace);

                            // Code
                            XSSFCell code = sheet.getRow(row).getCell(col + 7 + move);
                            String finalCode = "";
                            if (code != null) {
                                switch (code.getCellType()) {
                                    case STRING:
                                        finalCode = code.getStringCellValue();
                                        break;
                                    case NUMERIC:
                                        finalCode = Double.toString(code.getNumericCellValue());
                                        finalCode = finalCode.substring(0, finalCode.length()-2);
                                        break;
                                }
                            }
                            currentCourse.add(finalCode);

                            course.add(currentCourse);
                        }
                        col++;
                    } else {
                        break;
                    }
                }
                row++;
            } else {
                row++;
            }
        }
        System.out.println(course);
        
        // 创建一个新的XSSFWorkbook和XSSFSheet
        XSSFWorkbook newWorkbook = new XSSFWorkbook();
        XSSFSheet newSheet = newWorkbook.createSheet("NewSheet");

        // 遍历ArrayList并将数据写入新的XSSFSheet
        int rowNum = 0;
        for (ArrayList<String> currentCourse : course) {
            XSSFRow rowX = newSheet.createRow(rowNum++);
            int cellNum = 0;
            for (String data : currentCourse) {
                XSSFCell cell = rowX.createCell(cellNum++);
                cell.setCellValue(data);
            }
        }

        // 将XSSFWorkbook保存到新的Excel文件
        FileOutputStream outputStream = new FileOutputStream("/Users/daizhenjin/Downloads/新文件.xlsx");
        newWorkbook.write(outputStream);
        outputStream.close();
    }

    public static ArrayList<String> splitUnitsAndGrading(String input) {
        ArrayList<String> result = new ArrayList<>();
        String unitsPrefix = "Units:";
        String gradingPrefix = "Grading:";

        // 找到 Units: 和 Grading: 的索引
        int unitsIndex = input.indexOf(unitsPrefix);
        int gradingIndex = input.indexOf(gradingPrefix);

        if (unitsIndex != -1 && gradingIndex != -1) {
            // 获取 Units 和 Grading 之间的内容
            String units = input.substring(unitsIndex + unitsPrefix.length(), gradingIndex);
            // 获取 Grading 之后的内容
            String grading = input.substring(gradingIndex + gradingPrefix.length());

            result.add(units);
            result.add(grading);
        }

        return result;
    }
}
